// passport_forms_web.dart
import 'dart:math' as math;

import 'package:data_table_2/data_table_2.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:jiffy/jiffy.dart';

import 'package:alzajeltravel/controller/passport/passports_forms_controller.dart';
import 'package:alzajeltravel/controller/passport/passport_controller.dart';
import 'package:alzajeltravel/model/country_model.dart';
import 'package:alzajeltravel/model/passport/passport_model.dart';
import 'package:alzajeltravel/model/passport/traveler_review/traveler_review_model.dart';
import 'package:alzajeltravel/utils/app_funs.dart';
import 'package:alzajeltravel/utils/enums.dart';
import 'package:alzajeltravel/utils/widgets/country_picker.dart';
import 'package:alzajeltravel/view/frame/passport/contact_information_form.dart';
import 'package:alzajeltravel/view/frame/travelers_review/travelers_review_page.dart';

import 'passport_form_web.dart';

class PassportsFormsWebPage extends StatefulWidget {
  final int adultsCounter;
  final int childrenCounter;
  final int infantsInLapCounter;

  const PassportsFormsWebPage({
    super.key,
    required this.adultsCounter,
    required this.childrenCounter,
    required this.infantsInLapCounter,
  });

  @override
  State<PassportsFormsWebPage> createState() => _PassportsFormsWebPageState();
}

class _PassportsFormsWebPageState extends State<PassportsFormsWebPage> {
  final _vCtrl = ScrollController();
  final _hCtrl = ScrollController();
  final _webFormKey = GlobalKey<FormState>();

  final Set<String> _selectedTags = <String>{};

  // widths (قابلة للتعديل)
  static const double wName = 320;
  static const double wSurname = 200;
  static const double wDob = 230;
  static const double wSex = 160;
  static const double wPassport = 230;
  static const double wNationality = 240;
  static const double wIssuing = 240;
  static const double wExpiry = 230;

  double get _tableMinWidth =>
      wName + wSurname + wDob + wSex + wPassport + wNationality + wIssuing + wExpiry + 120; // + checkbox + margins

  @override
  void dispose() {
    _vCtrl.dispose();
    _hCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<PassportsFormsController>(
      init: PassportsFormsController(
        adultsCounter: widget.adultsCounter,
        childrenCounter: widget.childrenCounter,
        infantsInLapCounter: widget.infantsInLapCounter,
      ),
      builder: (formsController) {
        final cs = Theme.of(context).colorScheme;
        final travelers = formsController.sortedTravelers;

        return Scaffold(
          appBar: AppBar(title: Text('Travelers data'.tr)),
          body: Column(
            children: [
              // =========================
              // TABLE AREA (fixed height via Expanded)
              // =========================
              Expanded(
                child: LayoutBuilder(
                  builder: (context, constraints) {
                    final tableWidth = math.max(constraints.maxWidth, _tableMinWidth);

                    // ✅ Horizontal scroll outer
                    return Scrollbar(
                      controller: _hCtrl,
                      thumbVisibility: true,
                      notificationPredicate: (n) => n.metrics.axis == Axis.horizontal,
                      child: SingleChildScrollView(
                        controller: _hCtrl,
                        scrollDirection: Axis.horizontal,
                        child: SizedBox(
                          width: tableWidth,
                          // ✅ Vertical scroll inner (height bounded by Expanded)
                          child: Scrollbar(
                            controller: _vCtrl,
                            thumbVisibility: true,
                            notificationPredicate: (n) => n.metrics.axis == Axis.vertical,
                            child: SingleChildScrollView(
                              controller: _vCtrl,
                              child: Form(
                                key: _webFormKey,
                                child: DataTable2(
                                  showCheckboxColumn: true,
                                  headingRowHeight: 52,
                                  dataRowHeight: 90,
                                  columnSpacing: 18,
                                  horizontalMargin: 12,
                                  minWidth: tableWidth,
                                  // (اختياري) يساعد على شكل خطوط أوضح
                                  dividerThickness: 1,

                                  columns: [
                                    DataColumn2(fixedWidth: wName, label: Text('Given names'.tr)),
                                    DataColumn2(fixedWidth: wSurname, label: Text('SURNAMES'.tr)),
                                    DataColumn2(fixedWidth: wDob, label: Text('Date of birth'.tr)),
                                    DataColumn2(fixedWidth: wSex, label: Text('Sex'.tr)),
                                    DataColumn2(fixedWidth: wPassport, label: Text('DOCUMENT NUMBER'.tr)),
                                    DataColumn2(fixedWidth: wNationality, label: Text('NATIONALITY'.tr)),
                                    DataColumn2(fixedWidth: wIssuing, label: Text('ISSUING COUNTRY'.tr)),
                                    DataColumn2(fixedWidth: wExpiry, label: Text('DATE OF EXPIRY'.tr)),
                                  ],
                                  rows: [
                                    for (int i = 0; i < travelers.length; i++)
                                      _buildTravelerRow(
                                        formsController: formsController,
                                        tag: travelers[i].tag,
                                        travelerIndex: travelers[i].index,
                                        ageGroup: travelers[i].ageGroup,
                                        visualIndex: i,
                                        cs: cs,
                                      ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),

              // =========================
              // Contact form area (لمنع أي overflow)
              // =========================
              SizedBox(
                height: 260,
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(12),
                  child: ContactInformationForm(controller: formsController),
                ),
              ),

              // =========================
              // Bottom bar
              // =========================
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                height: 80,
                width: double.infinity,
                decoration: BoxDecoration(
                  color: cs.surfaceContainer,
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(16),
                    topRight: Radius.circular(16),
                  ),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text("Total flight".tr),
                          Text(
                            AppFuns.priceWithCoin(formsController.totalFlight, formsController.currency),
                            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 12),
                    Flexible(
                      fit: FlexFit.loose,
                      child: ElevatedButton(
                        onPressed: () async {
                          // ✅ validate table form
                          if (_webFormKey.currentState?.validate() != true) {
                            Get.snackbar(
                              'Validation'.tr,
                              'Please complete all required passport fields'.tr,
                              snackPosition: SnackPosition.BOTTOM,
                            );
                            return;
                          }

                          // ✅ validate contact form
                          if (!formsController.validateContactForm()) return;

                          context.loaderOverlay.show();

                          try {
                            final passports = formsController.collectModels();

                            final bookingResponse =
                                await formsController.createBookingServer(passports, formsController.contactModel);

                            if (bookingResponse == null) return;

                            final insertId = bookingResponse['insert_id'];
                            if (insertId == null) {
                              Get.snackbar(
                                'Error'.tr,
                                'Booking request failed, please try again.'.tr,
                                snackPosition: SnackPosition.BOTTOM,
                              );
                              return;
                            }

                            final List<dynamic> passengersJson =
                                (bookingResponse['passengers'] as List?) ?? const [];

                            final List<TravelerReviewModel> travelersReviewList = [];

                            for (int index = 0; index < passengersJson.length; index++) {
                              final Map<String, dynamic>? passengerJson =
                                  (passengersJson[index] is Map<String, dynamic>)
                                      ? passengersJson[index] as Map<String, dynamic>
                                      : null;

                              final double baseFare = _parseDouble(passengerJson?['Base_Amount']);
                              final double taxTotal = _parseDouble(passengerJson?['Tax_Total']);

                              final travelerPassport = PassportModel.fromJson({
                                "documentNumber": passengerJson?['passport_no'],
                                "givenNames": passengerJson?['first_name'],
                                "surnames": passengerJson?['last_name'],
                                "dateOfBirth": passengerJson?['dob'],
                                "sex": passengerJson?['gender'],
                                "nationality": passengerJson?['nationality'],
                                "issueCountry": passengerJson?['issue_country'],
                                "dateOfExpiry": passengerJson?['expiry_date'],
                              });

                              travelersReviewList.add(
                                TravelerReviewModel(
                                  passport: travelerPassport,
                                  baseFare: baseFare,
                                  taxTotal: taxTotal,
                                  seat: null,
                                  ageGroup: _ageGroupFromAny(passengerJson?['pax_type']),
                                ),
                              );
                            }

                            Get.to(() => TravelersReviewPage(
                                  travelers: travelersReviewList,
                                  insertId: insertId,
                                  contact: formsController.contactModel,
                                ));
                          } finally {
                            if (context.mounted) context.loaderOverlay.hide();
                          }
                        },
                        child: FittedBox(
                          fit: BoxFit.scaleDown,
                          child: Text("Save and continue".tr),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  DataRow2 _buildTravelerRow({
    required PassportsFormsController formsController,
    required String tag,
    required int travelerIndex,
    required AgeGroup ageGroup,
    required int visualIndex,
    required ColorScheme cs,
  }) {
    final onlyEnAlphaNumSpace = <TextInputFormatter>[
      FilteringTextInputFormatter.allow(RegExp(r"[A-Za-z0-9 ]")),
    ];

    final selected = _selectedTags.contains(tag);

    return DataRow2(
      selected: selected,
      onSelectChanged: (v) {
        setState(() {
          if (v == true) {
            _selectedTags.add(tag);
          } else {
            _selectedTags.remove(tag);
          }
        });
      },
      cells: [
        // Given names
        DataCell(
          GetBuilder<PassportController>(
            tag: tag,
            builder: (pc) {
              final ageLabel = formsController.ageGroupLabel(ageGroup);
              return WebTableTextField(
                width: wName,
                controller: pc.givenNamesCtr,
                autofocus: visualIndex == 0,
                formatters: onlyEnAlphaNumSpace,
                hint: 'Given names'.tr + ' (${'traveler'.tr} $travelerIndex: $ageLabel)',
              );
            },
          ),
        ),

        // Surnames
        DataCell(
          GetBuilder<PassportController>(
            tag: tag,
            builder: (pc) => WebTableTextField(
              width: wSurname,
              controller: pc.surnamesCtr,
              formatters: onlyEnAlphaNumSpace,
              hint: 'SURNAMES'.tr,
            ),
          ),
        ),

        // DOB (DateDropdownRow)
        DataCell(
          GetBuilder<PassportController>(
            tag: tag,
            builder: (pc) => WebTableDateDropdown(
              width: wDob,
              key: ValueKey('dob-$tag-${pc.model.dateOfBirth?.toIso8601String() ?? 'empty'}'),
              initialDate: pc.model.dateOfBirth,
              minDate: formsController.minDob(ageGroup),
              maxDate: formsController.maxDob(ageGroup),
              onDateChanged: pc.setDateOfBirth,
              validator: (date) {
                if (date == null) return 'Please select a valid date'.tr;
                if (date.isAfter(DateTime.now())) return 'Date of birth cannot be in the future'.tr;
                return null;
              },
            ),
          ),
        ),

        // Sex
        DataCell(
          GetBuilder<PassportController>(
            tag: tag,
            builder: (pc) => WebTableSexDropdown(
              width: wSex,
              controller: pc,
            ),
          ),
        ),

        // Passport no
        DataCell(
          GetBuilder<PassportController>(
            tag: tag,
            builder: (pc) => WebTableTextField(
              width: wPassport,
              controller: pc.documentNumberCtr,
              formatters: [FilteringTextInputFormatter.allow(RegExp(r"[A-Za-z0-9]"))],
              caps: TextCapitalization.characters,
              hint: 'DOCUMENT NUMBER'.tr,
            ),
          ),
        ),

        // Nationality
        DataCell(
          GetBuilder<PassportController>(
            tag: tag,
            builder: (pc) => WebTableCountryField(
              width: wNationality,
              label: 'NATIONALITY'.tr,
              value: countryDisplayName(pc.model.nationality, formsController.lang),
              onPick: () async {
                final CountryModel? picked = await Get.to<CountryModel>(() => const CountryPicker());
                if (picked != null) pc.setNationality(picked);
                return picked;
              },
            ),
          ),
        ),

        // Issuing country
        DataCell(
          GetBuilder<PassportController>(
            tag: tag,
            builder: (pc) => WebTableCountryField(
              width: wIssuing,
              label: 'ISSUING COUNTRY'.tr,
              value: countryDisplayName(pc.model.issuingCountry, formsController.lang),
              onPick: () async {
                final CountryModel? picked = await Get.to<CountryModel>(() => const CountryPicker());
                if (picked != null) pc.setIssuingCountry(picked);
                return picked;
              },
            ),
          ),
        ),

        // Expiry (DateDropdownRow)
        DataCell(
          GetBuilder<PassportController>(
            tag: tag,
            builder: (pc) => WebTableDateDropdown(
              width: wExpiry,
              key: ValueKey('expiry-$tag-${pc.model.dateOfExpiry?.toIso8601String() ?? 'empty'}'),
              initialDate: pc.model.dateOfExpiry,
              minDate: Jiffy.parseFromDateTime(formsController.lastDateInSearch).add(months: 6).dateTime,
              maxDate: Jiffy.parseFromDateTime(formsController.lastDateInSearch).add(years: 12).dateTime,
              onDateChanged: pc.setDateOfExpiry,
              validator: (date) {
                if (date == null) return 'Please select a valid date'.tr;
                return null;
              },
            ),
          ),
        ),
      ],
    );
  }

  double _parseDouble(dynamic v) {
    if (v == null) return 0.0;
    if (v is num) return v.toDouble();
    return double.tryParse(v.toString()) ?? 0.0;
  }

  AgeGroup _ageGroupFromAny(dynamic v) {
    final s = (v ?? '').toString().trim().toLowerCase();
    if (s == 'inf' || s == 'infant') return AgeGroup.infant;
    if (s == 'cnn' || s == 'chd' || s == 'child') return AgeGroup.child;
    if (s == 'adt' || s == 'adult') return AgeGroup.adult;
    return AgeGroup.adult;
  }
}
