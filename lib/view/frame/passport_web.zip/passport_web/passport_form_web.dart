// passport_form_web.dart
import 'package:alzajeltravel/model/passport/passport_model.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';

import 'package:alzajeltravel/controller/passport/passport_controller.dart';
import 'package:alzajeltravel/model/country_model.dart';
import 'package:alzajeltravel/utils/app_consts.dart';
import 'package:alzajeltravel/utils/enums.dart';
import 'package:alzajeltravel/utils/widgets/date_dropdown_row.dart';

String countryDisplayName(CountryModel? country, String lang) {
  if (country == null) return '';
  final dynamic name = country.name;
  if (name is Map) {
    return (name[lang] ?? name['en'] ?? '').toString();
  }
  return name?.toString() ?? '';
}

/// TextFormField داخل خلية جدول (بدون Expanded/Flexible)
class WebTableTextField extends StatelessWidget {
  final double width;
  final TextEditingController controller;
  final bool autofocus;
  final List<TextInputFormatter>? formatters;
  final TextCapitalization caps;
  final bool enabled;
  final String? hint;

  const WebTableTextField({
    super.key,
    required this.width,
    required this.controller,
    this.autofocus = false,
    this.formatters,
    this.caps = TextCapitalization.none,
    this.enabled = true,
    this.hint,
  });

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    return SizedBox(
      width: width,
      child: TextFormField(
        controller: controller,
        autofocus: autofocus,
        enabled: enabled,
        inputFormatters: formatters,
        textCapitalization: caps,
        maxLines: 1,
        style: const TextStyle(fontSize: AppConsts.normal),
        decoration: InputDecoration(
          isDense: true,
          // نخليه مثل الجدول (بدون إطار قوي)
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
          hintText: hint,
          hintStyle: TextStyle(color: cs.onSurfaceVariant.withOpacity(0.6)),
        ),
        validator: (val) {
          if (!enabled) return null;
          if (val == null || val.trim().isEmpty) {
            return 'Please enter'.tr;
          }
          return null;
        },
      ),
    );
  }
}

/// Country picker field داخل خلية جدول
class WebTableCountryField extends StatelessWidget {
  final double width;
  final String label;
  final String value;
  final Future<CountryModel?> Function() onPick;

  const WebTableCountryField({
    super.key,
    required this.width,
    required this.label,
    required this.value,
    required this.onPick,
  });

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    return SizedBox(
      width: width,
      child: TextFormField(
        key: ValueKey('$label-$value'),
        readOnly: true,
        initialValue: value,
        onTap: () async {
          await onPick();
          FocusScope.of(context).unfocus();
        },
        decoration: InputDecoration(
          isDense: true,
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
          hintText: 'Select'.tr + " ...",
          hintStyle: TextStyle(color: cs.onSurfaceVariant.withOpacity(0.6)),
        ),
        validator: (val) {
          if (value.trim().isEmpty) return 'Please enter'.tr;
          return null;
        },
      ),
    );
  }
}

/// Sex dropdown داخل خلية جدول
class WebTableSexDropdown extends StatelessWidget {
  final double width;
  final PassportController controller;

  const WebTableSexDropdown({
    super.key,
    required this.width,
    required this.controller,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width,
      child: DropdownButtonFormField<Sex>(
        value: controller.model.sex,
        isDense: true,
        iconSize: 18,
        decoration: const InputDecoration(
          isDense: true,
          border: InputBorder.none,
          contentPadding: EdgeInsets.symmetric(horizontal: 8, vertical: 10),
        ),
        items: Sex.values
            .map(
              (s) => DropdownMenuItem(
                value: s,
                child: Text('${s.label} (${s.key.toUpperCase()})', style: const TextStyle(fontSize: 14)),
              ),
            )
            .toList(),
        onChanged: controller.setSex,
        validator: (val) {
          if (val == null) return 'Please select sex'.tr;
          return null;
        },
      ),
    );
  }
}

/// DateDropdownRow داخل خلية جدول (مغلّف بـ SizedBox فقط)
class WebTableDateDropdown extends StatelessWidget {
  final double width;
  final DateTime? initialDate;
  final DateTime minDate;
  final DateTime maxDate;
  final ValueChanged<DateTime?> onDateChanged;
  final String? Function(DateTime?)? validator;

  const WebTableDateDropdown({
    super.key,
    required this.width,
    required this.initialDate,
    required this.minDate,
    required this.maxDate,
    required this.onDateChanged,
    this.validator,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width,
      child: DateDropdownRow(
        title: const SizedBox.shrink(),
        initialDate: initialDate,
        minDate: minDate,
        maxDate: maxDate,
        onDateChanged: onDateChanged,
        validator: validator,
      ),
    );
  }
}
